#!/usr/bin/env python3
"""Q6S5 KXMLBSPREAD feequeue trades→measured REJOIN harness.

Joins native public taker_* trade tape into measured books for arms
Q6S5A0 / Q6S5A1. Does not invent fills, PnL, depth, ROI, or Lee-Ready.
Fee stays CACHE-labeled (not live R1-P1). READY_NOT_SCORED; no self-SCORE.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path


def json_default(obj):
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(f'Object of type {type(obj).__name__} is not JSON serializable')


def dumps(obj) -> str:
    return json.dumps(obj, indent=2, default=json_default, sort_keys=False) + '\n'


LAB = Path(__file__).resolve().parent
PR58 = Path('/workspace/pr58-verify/repo')
sys.path[:0] = [
    str(LAB),
    str(PR58 / 'kalshi_q6s5_kxmlbspread_feequue_lab_20260925'),
    str(PR58 / 'kalshi_feebook_lab_20260922'),
    str(PR58 / 'kalshi_rails_lab_20260922'),
]

import orchestrator as orch  # noqa: E402

MEASURED = LAB / 'inputs' / 'measured'
TRADES = LAB / 'inputs' / 'trades'
PANEL_PATH = LAB / 'inputs' / 'panel_admitted.json'
RESULTS = LAB / 'results'
PROV = LAB / 'provenance'

KICK = Path(
    '/workspace/lab/governance/astra/packets/'
    'CONDUCTOR_KICK_SIMULATOR_Q6S5_KXMLBSPREAD_TRADES_JOIN_2026-09-25.json'
)
AUTHORITY = Path(
    '/workspace/lab/governance/astra/packets/'
    'CONDUCTOR_ACK_COLLECTOR_Q6S5_KXMLBSPREAD_TRADES_READY_2026-09-25.json'
)
FEE_PIN = Path(
    '/workspace/lab/governance/astra/packets/'
    'EXAMINER_FEE_PIN_Q6S5_KXMLBSPREAD_LIVE_SERIES_2026-09-25.json'
)
PRIOR_READY = Path(
    '/workspace/lab/governance/astra/packets/'
    'SIMULATOR_READY_Q6S5_KXMLBSPREAD_MEASURED_HARNESS_2026-09-25.json'
)

EXPECTED = {
    'kick': '76de2f1fa2461008bc1205e5004230ffd45fd2d3e6193d6cc0c11c616b499006',
    'authority': '95e3140bc7f5ad89287ee1ec5d648f6d938d1cbd18b8eba9615c2eed6b02fd11',
    'panel_admitted': 'e36de2d1ce6286dff90d25f2fae680170c8a469c443c1beed974ffe80383fba1',
    'fee_pin': '9c0f3554eedc582ed4bed940575bf7ee6c0540ce5134140c5ea19e7c458d2b6a',
    'prior_measured_ready': '1c84cc6b8d44ab720ffe537d6f3e9e257de12e2ca8706cc1ec96c51d127e7bb3',
    'orchestrator': 'e224686a1bbe4173f00e62c3d2cba78a3c48eecef45ed77c678564def9d5bbfc',
    'trades': {
        'COLLECTOR_READY_TRADES_NOT_SCORED.json': (
            '57194f272ab6bbe7a4d116c1fd4aabd5199e3a02a6cd96ed5cc6b7bd4bafb867'
        ),
        'DIGESTS.txt': '12b537a25b02fb33177d5a41c821f94677f1da88e8d1dd63178c3c9f59fac12b',
        'STATUS.json': 'e8e23f7d341c2d236243054663caf684c9e3fca40975dd48842d6b4052893e9a',
        'CAPTURE_MANIFEST.json': (
            'db7257d59faa4bb75acf21e0c5d2326b151d6ecf2a9690ffad13ffeb3744038f'
        ),
    },
    'measured': {
        'READY_NOT_SCORED.json': (
            '0617d540763d71a813672c9f9aa6766072c8461a1290c124b89e9fb3f2bf5de2'
        ),
        'CAPTURE_MANIFEST.json': (
            '2591dda5b73331f0328cf3d8a52d6021d22c5076800af27b454524d43027c6d2'
        ),
    },
}

EMPTY_HONEST_TICKER = 'KXMLBSPREAD-26SEP251840TBPHI-TB2'
EXPECTED_N_TRADES = 11744


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(Path(path).read_bytes())
    return h.hexdigest()


def et_now() -> str:
    return datetime.now().strftime('%Y-%m-%dT%H:%M:%S %Z').strip() or datetime.now().strftime(
        '%Y-%m-%dT%H:%M:%S ET'
    )


def verify_digests() -> dict:
    rows = []

    def check(label, path, expected):
        got = sha256_file(path)
        ok = got == expected
        rows.append(
            {
                'label': label,
                'path': str(path),
                'expected': expected,
                'got': got,
                'status': 'PASS' if ok else 'FAIL',
            }
        )
        return ok

    ok = True
    ok &= check('kick', KICK, EXPECTED['kick'])
    ok &= check('authority_ack', AUTHORITY, EXPECTED['authority'])
    ok &= check('panel_admitted', PANEL_PATH.resolve(), EXPECTED['panel_admitted'])
    ok &= check('fee_pin', FEE_PIN, EXPECTED['fee_pin'])
    ok &= check('prior_measured_ready', PRIOR_READY, EXPECTED['prior_measured_ready'])
    ok &= check('orchestrator.py', LAB / 'orchestrator.py', EXPECTED['orchestrator'])
    for name, expected in EXPECTED['trades'].items():
        ok &= check(f'trades/{name}', TRADES / name, expected)
    for name, expected in EXPECTED['measured'].items():
        ok &= check(f'measured/{name}', MEASURED / name, expected)
    if not ok:
        (PROV / 'digest_verification.json').write_text(
            dumps({'status': 'FAIL', 'rows': rows})
        )
        raise SystemExit('DIGEST_MISMATCH')
    return {'status': 'PASS', 'rows': rows}


def panel_tickers(panel: dict) -> list[str]:
    return [m['ticker'] for m in panel['markets']]


def latest_markets_by_ticker() -> dict[str, Path]:
    out = {}
    for p in sorted((MEASURED / 'raw' / 'markets').glob('*.json')):
        t = p.name.split('__')[-1].replace('.json', '')
        if t.endswith('.meta') or '.meta.' in p.name:
            continue
        out[t] = p
    return out


def dated_orderbooks_by_ticker() -> dict[str, list[Path]]:
    out: dict[str, list[Path]] = {}
    for p in sorted((MEASURED / 'raw' / 'orderbooks').glob('2026*.json')):
        t = p.name.split('__')[-1].replace('.json', '')
        if t.endswith('.meta'):
            continue
        out.setdefault(t, []).append(p)
    return out


def count_n_books(tickers: list[str], books: dict[str, list[Path]]) -> int:
    return sum(1 for t in tickers if books.get(t))


def load_public_trades(tickers: list[str]) -> dict:
    """Load public trade tape pages. Empty-honest ticker stays empty."""
    by_ticker: dict[str, list[dict]] = {}
    pages_n = 0
    empty_honest = []
    for t in tickers:
        root = TRADES / 'raw' / 'trades' / t
        rows: list[dict] = []
        if root.is_dir():
            for p in sorted(root.glob('page_*.json')):
                if '.meta' in p.name:
                    continue
                payload = json.loads(p.read_text())
                pages_n += 1
                rows.extend(payload.get('trades') or [])
        by_ticker[t] = rows
        if t == EMPTY_HONEST_TICKER or len(rows) == 0:
            # confirm STATUS empty_honest flag when present
            per = TRADES / 'per_ticker' / f'{t}.json'
            empty_flag = False
            if per.exists():
                meta = json.loads(per.read_text())
                empty_flag = bool(meta.get('empty_honest'))
            if empty_flag or t == EMPTY_HONEST_TICKER:
                empty_honest.append(
                    {
                        'ticker': t,
                        'n_trades': len(rows),
                        'empty_honest': True,
                        'note': 'Kept empty; no invent fills.',
                    }
                )
    n_trades = sum(len(v) for v in by_ticker.values())
    return {
        'by_ticker': by_ticker,
        'n_trades': n_trades,
        'n_tickers': len(tickers),
        'pages_n': pages_n,
        'empty_honest': empty_honest,
        'empty_honest_n': len(empty_honest),
    }


def classify_row_from_public_trade(tr: dict) -> dict:
    """Classify using native public taker_* only.

    Ticker is omitted from the classify input on purpose: orchestrator
    `_refuse_series_ticker` raises InventedFillRefused when a panel-admitted
    ticker is present on a classify row (guard against inventing strategy
    fills). Public tape taker_* values are passed verbatim; no Lee-Ready;
    no invented labels.
    """
    row = {
        'trade_id': tr.get('trade_id'),
        'taker_outcome_side': tr.get('taker_outcome_side'),
        'taker_book_side': tr.get('taker_book_side'),
        'taker_side': tr.get('taker_side'),
    }
    return orch.classify_native_taker(row)


def arm_q6s5a0_native_trades(trades_bundle: dict) -> dict:
    """Q6S5A0 maker_vs_taker_native on joined public trade tape."""
    all_rows = []
    per_ticker_counts = {}
    classify_errors = []
    classified = []
    for t, trades in trades_bundle['by_ticker'].items():
        per_ticker_counts[t] = {'n_trades': len(trades), 'n_classified': 0}
        for tr in trades:
            try:
                c = classify_row_from_public_trade(tr)
                classified.append(c)
                per_ticker_counts[t]['n_classified'] += 1
                all_rows.append(
                    {
                        'trade_id': tr.get('trade_id'),
                        'taker_outcome_side': tr.get('taker_outcome_side'),
                        'taker_book_side': tr.get('taker_book_side'),
                        'taker_side': tr.get('taker_side'),
                    }
                )
            except Exception as e:
                classify_errors.append(
                    {
                        'ticker': t,
                        'trade_id': tr.get('trade_id'),
                        'error': f'{type(e).__name__}: {e}',
                    }
                )
    partitions = None
    if all_rows:
        partitions = orch.partition_native(all_rows)
        # Drop bulky trade_ids lists from arm report (keep counts)
        partitions_slim = []
        for p in partitions:
            slim = dict(p)
            slim['trade_ids_omitted'] = True
            slim['trade_ids_n'] = len(slim.pop('trade_ids', []) or [])
            partitions_slim.append(slim)
        partitions = partitions_slim

    outcome_counts = {}
    for c in classified:
        k = c.get('taker_outcome_side')
        outcome_counts[str(k)] = outcome_counts.get(str(k), 0) + 1

    fee = orch.fee_output()
    return {
        'arm': 'Q6S5A0',
        'analysis_slice': 'maker_vs_taker_native',
        'n_trades_joined': trades_bundle['n_trades'],
        'n_classified_native': len(classified),
        'n_classify_errors': len(classify_errors),
        'classify_errors_sample': classify_errors[:5],
        'taker_outcome_side_counts': outcome_counts,
        'partitions': partitions,
        'per_ticker_counts': per_ticker_counts,
        'empty_honest': trades_bundle['empty_honest'],
        'ticker_omitted_for_classify': True,
        'ticker_omit_reason': (
            'orchestrator._refuse_series_ticker raises InventedFillRefused when a '
            'panel-admitted ticker is present on a classify row (anti-invent-fill). '
            'Public tape taker_outcome_side/taker_book_side/taker_side passed verbatim; '
            'no Lee-Ready; no invented taker labels.'
        ),
        'maker_vs_taker_roi_delta': None,
        'maker_vs_taker_roi_delta_reason': (
            'Joined native public taker_* for classification/partition counts only. '
            'ROI refused without strategy fill/PnL series. No Lee-Ready. '
            'orchestrator.partition_native keeps maker_vs_taker_roi_delta null by design.'
        ),
        'lee_ready': 'REFUSED',
        'fee_cache': fee,
        'cache_labeled': True,
        'live_r1p1': False,
        'claim_as_live_R1P1': False,
    }


def arm_q6s5a1_fresh(tickers: list[str], books: dict[str, list[Path]]) -> dict:
    """Q6S5A1 content_fresh_vs_stale_bin on successive measured books (same as prior)."""
    rows = []
    for t in tickers:
        paths = books.get(t) or []
        if len(paths) < 1:
            continue
        prev = None
        prev_tt = None
        for i, path in enumerate(paths):
            payload = json.loads(path.read_text())
            current = payload.get('orderbook_fp', payload)
            parts = path.name.split('__')
            tt = parts[2] if len(parts) >= 3 else str(i + 1)
            row = {
                'row_id': f'{t}__{path.name}',
                'queue_ahead': orch.rails.QUEUE_AHEAD_DEFAULT,
                'previous': prev,
                'current': current,
                'transaction_time': tt,
                'previous_transaction_time': prev_tt,
                'keepalive': False,
            }
            rows.append(row)
            prev = current
            prev_tt = tt
    classified = []
    errors = []
    for row in rows:
        try:
            classified.append(orch.classify_fresh_queue(row))
        except Exception as e:
            errors.append({'row_id': row.get('row_id'), 'error': f'{type(e).__name__}: {e}'})
    bins = None
    if classified:
        try:
            bins = orch.partition_fresh(rows if len(classified) == len(rows) else rows)
        except Exception as e:
            ok_ids = {c['row_id'] for c in classified}
            ok_rows = [r for r in rows if r['row_id'] in ok_ids]
            try:
                bins = orch.partition_fresh(ok_rows)
            except Exception as e2:
                errors.append(
                    {'partition_fresh': f'{type(e).__name__}/{type(e2).__name__}: {e2}'}
                )
                bins = None
    bins_slim = None
    if bins is not None:
        bins_slim = []
        for b in bins:
            slim = dict(b)
            slim['row_ids_omitted'] = True
            slim['row_ids_n'] = len(slim.pop('row_ids', []) or [])
            bins_slim.append(slim)
    fee = orch.fee_output()
    flag_counts = {}
    for c in classified:
        key = str(c.get('content_fresh_flag'))
        flag_counts[key] = flag_counts.get(key, 0) + 1
    return {
        'arm': 'Q6S5A1',
        'analysis_slice': 'content_fresh_vs_stale_bin',
        'rows_built': len(rows),
        'rows_classified': len(classified),
        'classify_errors_n': len(errors),
        'classify_errors_sample': errors[:5],
        'content_fresh_flag_counts': flag_counts,
        'bins': bins_slim,
        'fresh_vs_stale_gap': None,
        'fresh_vs_stale_gap_reason': (
            'classify_fresh_queue / partition_fresh keep fresh_vs_stale_gap null by '
            'design. No strategy fill or PnL series exists to form a gap. '
            'Content-fresh flags counted from measured books; gap is not ROI.'
        ),
        'queue_ahead_source': 'rails.QUEUE_AHEAD_DEFAULT',
        'queue_ahead_value': orch.rails.QUEUE_AHEAD_DEFAULT,
        'lee_ready': 'REFUSED',
        'fee_cache': fee,
        'cache_labeled': True,
        'live_r1p1': False,
        'claim_as_live_R1P1': False,
    }


def honest_settled_join(tickers: list[str], markets: dict[str, Path]) -> dict:
    joined = []
    active = []
    missing = []
    for t in tickers:
        if t not in markets:
            missing.append(t)
            continue
        payload = json.loads(markets[t].read_text())
        m = payload.get('market', payload)
        status = m.get('status')
        result = m.get('result')
        settlement_ts = m.get('settlement_ts')
        row = {
            'ticker': t,
            'status': status,
            'result': result,
            'settlement_ts': settlement_ts,
            'market_path': str(markets[t]),
            'market_sha256': sha256_file(markets[t]),
        }
        if status in ('finalized', 'determined', 'settled') and result not in (None, ''):
            joined.append(row)
        else:
            active.append(row)
    return {
        'settled_join_n': len(joined),
        'active_or_unset_n': len(active),
        'missing_n': len(missing),
        'joined': joined,
        'active_or_unset': active,
        'missing': missing,
        'note': (
            'Observational join of panel tickers to measured raw/markets '
            'status+result. Not fills, not PnL. orchestrator.settled_join(panel) '
            'remains null by design (panel.results/pnl null).'
        ),
    }


def main() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    PROV.mkdir(parents=True, exist_ok=True)

    runner_path = Path(__file__).resolve()
    runner_sha = sha256_file(runner_path)
    (PROV / 'runner_sha256_BEFORE_RUN.txt').write_text(runner_sha + '\n')
    orch_sha = sha256_file(LAB / 'orchestrator.py')
    (PROV / 'orchestrator_sha256_BEFORE_RUN.txt').write_text(orch_sha + '\n')

    digest_table = verify_digests()
    (PROV / 'digest_verification.json').write_text(dumps(digest_table))

    panel = json.loads(PANEL_PATH.read_text())
    tickers = panel_tickers(panel)
    books = dated_orderbooks_by_ticker()
    markets = latest_markets_by_ticker()

    trades_bundle = load_public_trades(tickers)
    if trades_bundle['n_trades'] != EXPECTED_N_TRADES:
        raise SystemExit(
            f"N_TRADES_MISMATCH got={trades_bundle['n_trades']} expected={EXPECTED_N_TRADES}"
        )
    if not any(e['ticker'] == EMPTY_HONEST_TICKER for e in trades_bundle['empty_honest']):
        raise SystemExit('EMPTY_HONEST_TBPHI_TB2_MISSING')
    if trades_bundle['by_ticker'][EMPTY_HONEST_TICKER]:
        raise SystemExit('EMPTY_HONEST_TBPHI_TB2_NOT_EMPTY')

    n_books = count_n_books(tickers, books)
    settled = honest_settled_join(tickers, markets)
    orch_settled = orch.settled_join(panel)

    a0 = arm_q6s5a0_native_trades(trades_bundle)
    a1 = arm_q6s5a1_fresh(tickers, books)
    fee = orch.fee_output()

    metrics = {
        'maker_vs_taker_roi_delta': None,
        'maker_vs_taker_roi_delta_reason': a0['maker_vs_taker_roi_delta_reason'],
        'fresh_vs_stale_gap': None,
        'fresh_vs_stale_gap_reason': a1['fresh_vs_stale_gap_reason'],
        'settled_join_n': settled['settled_join_n'],
        'settled_join_n_reason': settled['note'],
        'settled_join_orchestrator_panel': orch_settled,
        'n_books': n_books,
        'n_books_reason': (
            'Count of panel-admitted tickers with >=1 dated measured orderbook '
            f'under measured/raw/orderbooks (panel={len(tickers)}, with_books={n_books}).'
        ),
        'n_trades_joined': trades_bundle['n_trades'],
        'n_classified_native': a0['n_classified_native'],
        'empty_honest': trades_bundle['empty_honest'],
        'empty_honest_n': trades_bundle['empty_honest_n'],
        'content_fresh_flag_counts': a1['content_fresh_flag_counts'],
        'arm_a1_rows_classified': a1['rows_classified'],
        'results': None,
        'pnl': None,
        'results_pnl_reason': (
            'No strategy fills; public tape is observational. '
            'Unresolved inventory != profit; invent fills/PnL refused.'
        ),
        'lee_ready': 'REFUSED',
    }

    out = {
        'schema_id': 'astra.q6s5_kxmlbspread_feequue.trades_join.v0',
        'status': 'READY_NOT_SCORED',
        'scored': False,
        'keep_claim': False,
        'packet_id': 'Q6S5-KXMLBSPREAD-FEEQUEUE-HARNESS',
        'feature_family': 'Q6S5-MLBSPREAD-FEEQUEUE',
        'series': 'KXMLBSPREAD',
        'lab': str(LAB),
        'arms': {
            'Q6S5A0': 'maker_vs_taker_native',
            'Q6S5A1': 'content_fresh_vs_stale_bin',
        },
        'knob': 'analysis_slice',
        'runner': str(runner_path),
        'runner_sha256': runner_sha,
        'orchestrator': str(LAB / 'orchestrator.py'),
        'orchestrator_sha256': orch_sha,
        'digest_verification': digest_table,
        'kick_sha256': EXPECTED['kick'],
        'authority_sha256': EXPECTED['authority'],
        'fee_pin_sha256': EXPECTED['fee_pin'],
        'prior_measured_ready_sha256': EXPECTED['prior_measured_ready'],
        'panel_admitted_sha256': EXPECTED['panel_admitted'],
        'panel_admitted_at': panel.get('admitted_at'),
        'panel_markets_n': len(tickers),
        'coverage': {
            'series': '1/1',
            'events': '6/6',
            'markets': '12/12',
            'orderbooks': f'{n_books}/12',
            'trades_tickers': f"{trades_bundle['n_tickers']}/12",
            'n_trades': trades_bundle['n_trades'],
            'empty_honest_n': trades_bundle['empty_honest_n'],
            'gaps': [],
            'honest_full_sweep': n_books == 12 and trades_bundle['n_tickers'] == 12,
        },
        'fee': {
            'label': 'CACHE',
            'fee_type': fee['fee_type'],
            'multiplier': fee['multiplier'],
            'cache_labeled': True,
            'live_r1p1': False,
            'claim_as_live_R1P1': False,
            'fee_pin_sha256': EXPECTED['fee_pin'],
            'fee_dollars': None,
            'note': (
                'CACHE quadratic×0.5 (Examiner fee pin 9c0f3554… formula_id ABSENT) '
                '— NEVER claim as live R1-P1'
            ),
            'fee_output': fee,
        },
        'metrics': metrics,
        'arm_reports': {'Q6S5A0': a0, 'Q6S5A1': a1},
        'settled_join_detail': {
            'settled_join_n': settled['settled_join_n'],
            'active_or_unset_n': settled['active_or_unset_n'],
            'missing_n': settled['missing_n'],
            'joined_tickers': [r['ticker'] for r in settled['joined']],
            'active_tickers': [r['ticker'] for r in settled['active_or_unset']],
            'note': settled['note'],
        },
        'refuses': [
            'invent fills/PnL',
            'self-SCORE',
            'KEEP claim',
            'claim CACHE as R1-P1',
            'live orders',
            'Lee-Ready',
            'admit.py',
            'retune Q6-000 / Cap-SR / S1 KXMLBGAME ML',
            'edit Examiner SCORE/HOLD / Collector trades bytes',
            'mutate prior measured READY',
        ],
        'stamped_at_et': et_now(),
        'note': (
            'Trades→measured REJOIN complete. Native public taker_* joined for '
            'Q6S5A0 classification/partition counts; ROI/gap honest-null. '
            'A1 content_fresh from measured books. Fee CACHE≠R1-P1. '
            'empty_honest TBPHI-TB2 kept empty. READY_NOT_SCORED; Examiner owns SCORE.'
        ),
    }

    results_path = RESULTS / 'TRADES_JOIN_RUN_RESULTS.json'
    results_path.write_text(dumps(out))

    metrics_path = RESULTS / 'TRADES_JOIN_METRICS.json'
    metrics_path.write_text(
        dumps(
            {
                'maker_vs_taker_roi_delta': metrics['maker_vs_taker_roi_delta'],
                'maker_vs_taker_roi_delta_reason': metrics['maker_vs_taker_roi_delta_reason'],
                'fresh_vs_stale_gap': metrics['fresh_vs_stale_gap'],
                'fresh_vs_stale_gap_reason': metrics['fresh_vs_stale_gap_reason'],
                'settled_join_n': metrics['settled_join_n'],
                'settled_join_n_reason': metrics['settled_join_n_reason'],
                'n_books': metrics['n_books'],
                'n_books_reason': metrics['n_books_reason'],
                'n_trades_joined': metrics['n_trades_joined'],
                'n_classified_native': metrics['n_classified_native'],
                'empty_honest': metrics['empty_honest'],
                'empty_honest_n': metrics['empty_honest_n'],
                'content_fresh_flag_counts': metrics['content_fresh_flag_counts'],
                'arm_a1_rows_classified': metrics['arm_a1_rows_classified'],
                'results': None,
                'pnl': None,
                'lee_ready': 'REFUSED',
                'fee_cache_labeled': True,
                'live_r1p1': False,
                'claim_as_live_R1P1': False,
                'fee_pin_sha256': EXPECTED['fee_pin'],
                'status': 'READY_NOT_SCORED',
                'scored': False,
                'keep_claim': False,
            }
        )
    )

    digest_lines = []
    artifacts = [
        LAB / 'run_trades_join.py',
        LAB / 'orchestrator.py',
        results_path,
        metrics_path,
        PROV / 'digest_verification.json',
        PROV / 'runner_sha256_BEFORE_RUN.txt',
        PROV / 'orchestrator_sha256_BEFORE_RUN.txt',
    ]
    for p in artifacts:
        digest_lines.append(f'{sha256_file(p)}  {p}')
    digest_text = '\n'.join(digest_lines) + '\n'
    (RESULTS / 'DIGESTS.txt').write_text(digest_text)
    (LAB / 'DIGESTS.txt').write_text(digest_text)

    # Confirm prior READY untouched after run
    prior_got = sha256_file(PRIOR_READY)
    if prior_got != EXPECTED['prior_measured_ready']:
        raise SystemExit(f'PRIOR_READY_MUTATED got={prior_got}')

    print(
        json.dumps(
            {
                'status': 'READY_NOT_SCORED',
                'runner_sha256': runner_sha,
                'orchestrator_sha256': orch_sha,
                'metrics': {
                    'maker_vs_taker_roi_delta': None,
                    'fresh_vs_stale_gap': None,
                    'settled_join_n': metrics['settled_join_n'],
                    'n_books': metrics['n_books'],
                    'n_trades_joined': metrics['n_trades_joined'],
                    'n_classified_native': metrics['n_classified_native'],
                    'empty_honest_n': metrics['empty_honest_n'],
                    'content_fresh_flag_counts': metrics['content_fresh_flag_counts'],
                },
                'results_path': str(results_path),
                'results_sha256': sha256_file(results_path),
                'metrics_path': str(metrics_path),
                'metrics_sha256': sha256_file(metrics_path),
                'prior_ready_sha256': prior_got,
            },
            indent=2,
            default=json_default,
        )
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
