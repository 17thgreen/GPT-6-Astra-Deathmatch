#!/usr/bin/env python3
"""Q6S5 KXMLBSPREAD GET-only public trades/fills tape capture (Astra Collector).

Hard rules:
- GET-only public Kalshi /markets/trades for exactly 12 locked tickers
- No invent fills/PnL/taker labels; no Lee-Ready; no scoring
- Spacing: >=20.0s between EVERY Kalshi GET, <=3 rpm
- 429: Retry-After or 30->60->120->240 cap 600; 1 retry/logical; +2s for 30min;
  >=3x429 in 10min -> PAUSE_429_STORM 10min
- Do not touch measured/ or ADMIT-1
- Stamp COLLECTOR_READY_TRADES_NOT_SCORED when all 12 resolved
"""
from __future__ import annotations

import hashlib
import json
import os
import signal
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE = "https://api.elections.kalshi.com/trade-api/v2"
ROOT = Path(__file__).resolve().parent
KICK_PATH = Path(
    "/workspace/lab/governance/astra/packets/"
    "CONDUCTOR_KICK_COLLECTOR_Q6S5_KXMLBSPREAD_TRADES_FILLS_2026-09-25.json"
)
ACCEPT_PATH = Path(
    "/workspace/lab/governance/astra/packets/"
    "CONDUCTOR_ACCEPT_EXAMINER_Q6S5_KXMLBSPREAD_MEASURED_HARNESS_ITERATE_2026-09-25.json"
)
KICK_SHA_PIN = "b7b741745ef513ec5f9b7e31554263baec54518add1da25201e4de8c7665b836"
ACCEPT_SHA_PIN = "54b0b1b7d57d42f3a2f2d0caefd72be734532eaae8d8c54fbcb8817a7df99a71"

TICKERS = [
    "KXMLBSPREAD-26SEP242140HOUATH-ATH2",
    "KXMLBSPREAD-26SEP242140HOUATH-HOU2",
    "KXMLBSPREAD-26SEP242140LAASEA-LAA2",
    "KXMLBSPREAD-26SEP242140LAASEA-SEA2",
    "KXMLBSPREAD-26SEP242210SDLAD-LAD2",
    "KXMLBSPREAD-26SEP242210SDLAD-SD2",
    "KXMLBSPREAD-26SEP251840PITDET-DET2",
    "KXMLBSPREAD-26SEP251840PITDET-PIT2",
    "KXMLBSPREAD-26SEP251840TBPHI-PHI2",
    "KXMLBSPREAD-26SEP251840TBPHI-TB2",
    "KXMLBSPREAD-26SEP251845NYMWSH-NYM2",
    "KXMLBSPREAD-26SEP251845NYMWSH-WSH2",
]

MIN_GAP_S = 20.0
AFTER_429_EXTRA_S = 2.0
AFTER_429_WINDOW_S = 30 * 60
STORM_N = 3
STORM_WINDOW_S = 10 * 60
STORM_PAUSE_S = 10 * 60
MAX_PAGES_PER_TICKER = 50
MAX_WALL_S = 90 * 60
LIMIT = 1000
USER_AGENT = "AstraCollector-Q6S5-TRADES/1.0"
BACKOFF_STEPS = [30, 60, 120, 240]  # then cap 600
BACKOFF_CAP = 600

SERIES = "KXMLBSPREAD"
PACKET_ID = "Q6S5-KXMLBSPREAD-FEEQUEUE-HARNESS"
CAPTURE_ROOT_REL = "lab/astra-capture/q6s5-kxmlbspread/trades_fills_2026-09-25/"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_iso(dt: Optional[datetime] = None) -> str:
    d = dt or utc_now()
    return d.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, obj: Any) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(obj, indent=2, sort_keys=False) + "\n"
    path.write_text(raw, encoding="utf-8")
    return sha256_bytes(raw.encode("utf-8"))


def append_jsonl(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, separators=(",", ":")) + "\n")


def verify_pins() -> None:
    kick_sha = sha256_file(KICK_PATH)
    accept_sha = sha256_file(ACCEPT_PATH)
    if kick_sha != KICK_SHA_PIN:
        raise SystemExit(f"ABORT kick sha mismatch: got {kick_sha} want {KICK_SHA_PIN}")
    if accept_sha != ACCEPT_SHA_PIN:
        raise SystemExit(f"ABORT accept sha mismatch: got {accept_sha} want {ACCEPT_SHA_PIN}")
    kick = json.loads(KICK_PATH.read_text(encoding="utf-8"))
    if kick.get("tickers") != TICKERS:
        raise SystemExit("ABORT tickers mismatch vs kick packet")
    print(f"[pin] kick_sha={kick_sha} accept_sha={accept_sha} n_tickers={len(TICKERS)}", flush=True)


class RateGovernor:
    def __init__(self) -> None:
        self.min_gap = MIN_GAP_S
        self.last_get_mono: Optional[float] = None
        self.extra_until_mono: float = 0.0
        self.recent_429: List[float] = []
        self.pause_until_mono: float = 0.0
        self.in_storm = False
        self.backoff_idx = 0

    def current_gap(self) -> float:
        now = time.monotonic()
        gap = self.min_gap
        if now < self.extra_until_mono:
            gap = self.min_gap + AFTER_429_EXTRA_S
        return gap

    def note_429(self) -> None:
        now = time.monotonic()
        self.recent_429.append(now)
        self.extra_until_mono = max(self.extra_until_mono, now + AFTER_429_WINDOW_S)
        cutoff = now - STORM_WINDOW_S
        self.recent_429 = [t for t in self.recent_429 if t >= cutoff]
        if len(self.recent_429) >= STORM_N:
            self.pause_until_mono = max(self.pause_until_mono, now + STORM_PAUSE_S)
            self.in_storm = True
            print(f"[PAUSE_429_STORM] pausing {STORM_PAUSE_S}s", flush=True)

    def next_cooldown(self, retry_after: Optional[float]) -> float:
        if retry_after is not None and retry_after > 0:
            return float(retry_after)
        if self.backoff_idx < len(BACKOFF_STEPS):
            c = BACKOFF_STEPS[self.backoff_idx]
            self.backoff_idx += 1
        else:
            c = BACKOFF_CAP
        return float(min(c, BACKOFF_CAP))

    def reset_backoff(self) -> None:
        self.backoff_idx = 0

    def wait_before_get(self) -> Dict[str, Any]:
        meta: Dict[str, Any] = {"paused": False, "storm": False, "wait_s": 0.0, "spacing_s": self.min_gap}
        now = time.monotonic()
        if now < self.pause_until_mono:
            sleep_s = self.pause_until_mono - now
            meta.update({"paused": True, "storm": True, "wait_s": sleep_s, "reason": "PAUSE_429_STORM"})
            print(f"[gov] PAUSE_429_STORM sleep {sleep_s:.1f}s", flush=True)
            time.sleep(sleep_s)
            now = time.monotonic()
            self.in_storm = False
        gap = self.current_gap()
        meta["spacing_s"] = gap
        if self.last_get_mono is not None:
            elapsed = now - self.last_get_mono
            if elapsed < gap:
                wait = gap - elapsed
                meta["wait_s"] = wait
                time.sleep(wait)
        self.last_get_mono = time.monotonic()
        return meta


class State:
    def __init__(self) -> None:
        self.start_utc = utc_iso()
        self.start_mono = time.monotonic()
        self.phase = "STARTING"
        self.n_200 = 0
        self.n_429 = 0
        self.n_other = 0
        self.stop = False
        self.per_ticker: Dict[str, Dict[str, Any]] = {}
        for t in TICKERS:
            self.per_ticker[t] = {
                "ticker": t,
                "status": "pending",
                "n_pages": 0,
                "n_trades_total": 0,
                "empty_honest": False,
                "gap_reasons": [],
                "http_outcomes": [],
                "first_created_time": None,
                "last_created_time": None,
                "taker_field_keys_observed": [],
            }


STATE = State()
GOV = RateGovernor()


def update_status(**extra: Any) -> None:
    elapsed = time.monotonic() - STATE.start_mono
    progress = []
    for t in TICKERS:
        info = STATE.per_ticker[t]
        progress.append({
            "ticker": t,
            "status": info["status"],
            "n_pages": info["n_pages"],
            "n_trades_total": info["n_trades_total"],
            "empty_honest": info["empty_honest"],
            "gap_reasons": list(info["gap_reasons"]),
        })
    payload: Dict[str, Any] = {
        "schema_id": "astra.q6s5_trades_fills.status.v0",
        "series": SERIES,
        "packet_id": PACKET_ID,
        "phase": STATE.phase,
        "start_utc": STATE.start_utc,
        "updated_utc": utc_iso(),
        "elapsed_s": round(elapsed, 1),
        "n_200": STATE.n_200,
        "n_429": STATE.n_429,
        "n_other": STATE.n_other,
        "n_tickers": 12,
        "tickers_done": sum(1 for t in TICKERS if STATE.per_ticker[t]["status"] in ("ok", "empty_honest", "gap")),
        "per_ticker": progress,
        "kick_sha256": KICK_SHA_PIN,
        "accept_sha256": ACCEPT_SHA_PIN,
        "results": None,
        "pnl": None,
        "lee_ready": False,
        "rules": [
            "GET_only",
            "no_orders",
            "no_invent_fills",
            "no_lee_ready",
            "no_scoring",
            "spacing_ge_20s",
            "taker_fields_preserved_as_returned",
        ],
    }
    payload.update(extra)
    write_json(ROOT / "STATUS.json", payload)


def wall_exceeded() -> bool:
    return (time.monotonic() - STATE.start_mono) >= MAX_WALL_S


def do_get(url: str, ticker: str, page: int, cursor_in: Optional[str], retry_count: int) -> Dict[str, Any]:
    """Perform one spaced GET. Returns result dict."""
    gov_meta = GOV.wait_before_get()
    spacing_s = gov_meta.get("spacing_s", MIN_GAP_S)
    path = url.split("kalshi.com")[-1] if "kalshi.com" in url else url
    ts = utc_iso()
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    result: Dict[str, Any] = {
        "ts_utc": ts,
        "ticker": ticker,
        "page": page,
        "url": url,
        "url_path": path,
        "cursor_in": cursor_in,
        "retry_count": retry_count,
        "spacing_s": spacing_s,
        "http_status": None,
        "body": None,
        "body_sha256": None,
        "cursor_out": None,
        "n_trades_page": 0,
        "retry_after": None,
        "error": None,
    }
    try:
        with urlopen(req, timeout=60) as resp:
            body = resp.read()
            status = resp.status
            result["http_status"] = status
            result["body"] = body
            result["body_sha256"] = sha256_bytes(body)
            if status == 200:
                STATE.n_200 += 1
                GOV.reset_backoff()
                try:
                    parsed = json.loads(body.decode("utf-8"))
                    trades = parsed.get("trades") or []
                    if not isinstance(trades, list):
                        trades = []
                    result["n_trades_page"] = len(trades)
                    cursor_out = parsed.get("cursor") or None
                    if cursor_out == "":
                        cursor_out = None
                    result["cursor_out"] = cursor_out
                    result["parsed"] = parsed
                except json.JSONDecodeError as e:
                    result["error"] = f"json_decode:{e}"
                    STATE.n_other += 1
                    # reclassify: we counted 200 but treat as other for honesty
            else:
                STATE.n_other += 1
    except HTTPError as e:
        result["http_status"] = e.code
        retry_after = e.headers.get("Retry-After") if e.headers else None
        ra_f: Optional[float] = None
        if retry_after:
            try:
                ra_f = float(retry_after)
            except ValueError:
                ra_f = None
        result["retry_after"] = ra_f
        try:
            err_body = e.read()
            result["body"] = err_body
            result["body_sha256"] = sha256_bytes(err_body)
        except Exception:
            pass
        if e.code == 429:
            STATE.n_429 += 1
            GOV.note_429()
            cooldown = GOV.next_cooldown(ra_f)
            result["cooldown_s"] = cooldown
            append_jsonl(ROOT / "http_429.jsonl", {
                "ts_utc": ts,
                "poller": "q6s5_trades_fills",
                "path": path,
                "status": 429,
                "retry_after": ra_f,
                "spacing_now_s": spacing_s,
                "cooldown_s": cooldown,
            })
        else:
            STATE.n_other += 1
            result["error"] = f"HTTPError:{e.code}:{e.reason}"
    except URLError as e:
        STATE.n_other += 1
        result["error"] = f"URLError:{e.reason}"
        result["http_status"] = None
    except Exception as e:
        STATE.n_other += 1
        result["error"] = f"{type(e).__name__}:{e}"
        result["http_status"] = None

    append_jsonl(ROOT / "requests.jsonl", {
        "ts_utc": result["ts_utc"],
        "ticker": ticker,
        "page": page,
        "status": result["http_status"],
        "url_path": result["url_path"],
        "retry_after": result["retry_after"],
        "spacing_s": spacing_s,
        "n_trades": result["n_trades_page"],
        "body_sha256": result["body_sha256"],
        "retry_count": retry_count,
    })
    return result


def save_page(ticker: str, page: int, result: Dict[str, Any]) -> None:
    tdir = ROOT / "raw" / "trades" / ticker
    tdir.mkdir(parents=True, exist_ok=True)
    page_name = f"page_{page:04d}.json"
    meta_name = f"page_{page:04d}.meta.json"
    body = result.get("body")
    if body is not None:
        # pretty JSON if valid parse, else raw bytes as text fallback
        try:
            parsed = json.loads(body.decode("utf-8"))
            page_path = tdir / page_name
            write_json(page_path, parsed)
            # recompute sha of what we wrote? Spec says sha256_of_body of response.
            # Keep original response body sha in meta.
        except Exception:
            (tdir / page_name).write_bytes(body)
    meta = {
        "http_status": result["http_status"],
        "url": result["url"],
        "ts_utc": result["ts_utc"],
        "sha256_of_body": result["body_sha256"],
        "cursor_in": result["cursor_in"],
        "cursor_out": result["cursor_out"],
        "n_trades_page": result["n_trades_page"],
        "retry_count": result["retry_count"],
    }
    write_json(tdir / meta_name, meta)


def observe_taker_keys(trades: List[Dict[str, Any]], observed: Set[str]) -> None:
    for tr in trades:
        if not isinstance(tr, dict):
            continue
        for k in tr.keys():
            if "taker" in k.lower():
                observed.add(k)


def capture_ticker(ticker: str) -> None:
    info = STATE.per_ticker[ticker]
    info["status"] = "in_progress"
    update_status()
    print(f"[ticker] START {ticker}", flush=True)

    cursor: Optional[str] = None
    page = 0
    taker_keys: Set[str] = set()
    first_ct: Optional[str] = None
    last_ct: Optional[str] = None
    got_any_200 = False
    durable_gap = False

    while page < MAX_PAGES_PER_TICKER:
        if STATE.stop or wall_exceeded():
            info["gap_reasons"].append("wall_or_stop")
            durable_gap = True
            break

        page += 1
        qs = {"ticker": ticker, "limit": LIMIT}
        if cursor:
            qs["cursor"] = cursor
        url = f"{BASE}/markets/trades?{urlencode(qs)}"

        # logical request: at most 1 retry on 429
        result = do_get(url, ticker, page, cursor, retry_count=0)
        info["http_outcomes"].append(result["http_status"])

        if result["http_status"] == 429:
            cooldown = result.get("cooldown_s")
            if cooldown is None:
                cooldown = GOV.next_cooldown(result.get("retry_after"))
            print(f"[429] {ticker} page={page} cooldown={cooldown}s then 1 retry", flush=True)
            time.sleep(float(cooldown))
            if wall_exceeded():
                info["gap_reasons"].append("wall_during_429_backoff")
                durable_gap = True
                break
            result = do_get(url, ticker, page, cursor, retry_count=1)
            info["http_outcomes"].append(result["http_status"])
            if result["http_status"] == 429:
                info["gap_reasons"].append("429_exhausted_retry")
                durable_gap = True
                save_page(ticker, page, result)
                break

        if result["http_status"] != 200:
            err = result.get("error") or f"status_{result['http_status']}"
            info["gap_reasons"].append(f"http_fail:{err}")
            durable_gap = True
            if result.get("body") is not None:
                save_page(ticker, page, result)
            break

        # success 200
        got_any_200 = True
        save_page(ticker, page, result)
        parsed = result.get("parsed") or {}
        trades = parsed.get("trades") or []
        if not isinstance(trades, list):
            trades = []
        info["n_pages"] = page
        info["n_trades_total"] += len(trades)
        observe_taker_keys(trades, taker_keys)

        for tr in trades:
            if isinstance(tr, dict):
                ct = tr.get("created_time") or tr.get("ts") or tr.get("created_ts")
                if isinstance(ct, str):
                    if first_ct is None or ct < first_ct:
                        first_ct = ct
                    if last_ct is None or ct > last_ct:
                        last_ct = ct

        cursor_out = result.get("cursor_out")
        print(
            f"[page] {ticker} page={page} n={len(trades)} cursor_out={'yes' if cursor_out else 'no'} "
            f"n200={STATE.n_200} n429={STATE.n_429}",
            flush=True,
        )
        update_status()

        if not cursor_out:
            break
        cursor = cursor_out
    else:
        # hit page cap
        info["gap_reasons"].append("page_cap_50")
        durable_gap = True

    info["taker_field_keys_observed"] = sorted(taker_keys)
    info["first_created_time"] = first_ct
    info["last_created_time"] = last_ct

    if durable_gap:
        info["status"] = "gap"
        info["empty_honest"] = False
    elif got_any_200 and info["n_trades_total"] == 0:
        info["status"] = "empty_honest"
        info["empty_honest"] = True
    elif got_any_200:
        info["status"] = "ok"
        info["empty_honest"] = False
    else:
        info["status"] = "gap"
        info["gap_reasons"].append("no_successful_page")
        info["empty_honest"] = False

    # write per_ticker summary
    summary = {
        "ticker": ticker,
        "http_outcomes": info["http_outcomes"],
        "n_pages": info["n_pages"],
        "n_trades_total": info["n_trades_total"],
        "empty_honest": info["empty_honest"],
        "first_created_time": info["first_created_time"],
        "last_created_time": info["last_created_time"],
        "taker_field_keys_observed": info["taker_field_keys_observed"],
        "gap_reasons": list(info["gap_reasons"]),
        "status": info["status"],
    }
    write_json(ROOT / "per_ticker" / f"{ticker}.json", summary)
    print(f"[ticker] DONE {ticker} status={info['status']} n_trades={info['n_trades_total']}", flush=True)
    update_status()


def build_manifest_and_digests() -> Dict[str, str]:
    """Walk capture root, write CAPTURE_MANIFEST.json and DIGESTS.txt. Returns path->sha map."""
    digests: Dict[str, str] = {}
    files: List[Dict[str, Any]] = []
    skip_names = {"CAPTURE_MANIFEST.json", "DIGESTS.txt", "COLLECTOR_READY_TRADES_NOT_SCORED.json",
                  "INCOMPLETE_HONEST.json", "capture.stdout.log", "capture.stderr.log", "capture.pid"}
    # Include everything except we will re-hash after writing READY; first pass all except self-referential
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames.sort()
        for fn in sorted(filenames):
            p = Path(dirpath) / fn
            rel = str(p.relative_to(ROOT))
            if fn in ("CAPTURE_MANIFEST.json", "DIGESTS.txt"):
                continue
            if fn.endswith(".pyc") or "__pycache__" in rel:
                continue
            try:
                h = sha256_file(p)
            except Exception:
                continue
            digests[rel] = h
            files.append({"path": rel, "sha256": h, "size": p.stat().st_size})

    manifest = {
        "schema_id": "astra.q6s5_trades_fills.manifest.v0",
        "series": SERIES,
        "packet_id": PACKET_ID,
        "capture_root": CAPTURE_ROOT_REL,
        "stamped_at_utc": utc_iso(),
        "n_files": len(files),
        "files": files,
        "kick_sha256": KICK_SHA_PIN,
        "accept_sha256": ACCEPT_SHA_PIN,
    }
    write_json(ROOT / "CAPTURE_MANIFEST.json", manifest)
    digests["CAPTURE_MANIFEST.json"] = sha256_file(ROOT / "CAPTURE_MANIFEST.json")

    lines = [
        f"# Q6S5 KXMLBSPREAD trades_fills DIGESTS  updated={utc_iso()}",
        f"# kick                {KICK_SHA_PIN}",
        f"# accept              {ACCEPT_SHA_PIN}",
        f"# series={SERIES} packet_id={PACKET_ID}",
        f"# capture_root={CAPTURE_ROOT_REL}",
    ]
    for rel in sorted(digests.keys()):
        lines.append(f"{digests[rel]}  {rel}")
    digests_text = "\n".join(lines) + "\n"
    (ROOT / "DIGESTS.txt").write_text(digests_text, encoding="utf-8")
    digests["DIGESTS.txt"] = sha256_file(ROOT / "DIGESTS.txt")
    # rewrite DIGESTS including itself? measured style includes DIGESTS of other files but DIGESTS itself
    # gets listed when READY references it. Keep DIGESTS without self-hash line for stability;
    # READY artifact_digests will hash DIGESTS.txt file.
    return digests


def stamp_ready(digests: Dict[str, str]) -> Path:
    tickers_ok = []
    tickers_gap = []
    n_trades_total = 0
    n_empty = 0
    for t in TICKERS:
        info = STATE.per_ticker[t]
        n_trades_total += info["n_trades_total"]
        if info["status"] in ("ok", "empty_honest"):
            tickers_ok.append(t)
            if info["empty_honest"]:
                n_empty += 1
        else:
            tickers_gap.append({"ticker": t, "gap_reasons": list(info["gap_reasons"])})

    end_utc = utc_iso()
    # artifact digests for key files (compute after writing READY needs two-pass for READY self)
    ready_path = ROOT / "COLLECTOR_READY_TRADES_NOT_SCORED.json"
    payload: Dict[str, Any] = {
        "schema_id": "astra.q6s5_trades_fills.ready_not_scored.v0",
        "status": "COLLECTOR_READY_TRADES_NOT_SCORED",
        "series": SERIES,
        "packet_id": PACKET_ID,
        "kick_sha256": KICK_SHA_PIN,
        "accept_sha256": ACCEPT_SHA_PIN,
        "capture_root": CAPTURE_ROOT_REL,
        "start_utc": STATE.start_utc,
        "end_utc": end_utc,
        "n_tickers": 12,
        "tickers_ok": tickers_ok,
        "tickers_gap": tickers_gap,
        "n_trades_total": n_trades_total,
        "n_empty_honest": n_empty,
        "n_200": STATE.n_200,
        "n_429": STATE.n_429,
        "n_other": STATE.n_other,
        "taker_fields_preserved": True,
        "lee_ready": False,
        "fee_label": "untouched / CACHE unrelated",
        "results": None,
        "pnl": None,
        "artifact_digests": {
            "STATUS.json": digests.get("STATUS.json"),
            "CAPTURE_MANIFEST.json": digests.get("CAPTURE_MANIFEST.json"),
            "DIGESTS.txt": digests.get("DIGESTS.txt"),
            "requests.jsonl": digests.get("requests.jsonl"),
            "http_429.jsonl": digests.get("http_429.jsonl"),
        },
        "note": "honest GET-only; empty≠invent; Examiner/Simulator own join/SCORE",
    }
    write_json(ready_path, payload)
    ready_sha = sha256_file(ready_path)
    payload["artifact_digests"]["COLLECTOR_READY_TRADES_NOT_SCORED.json"] = ready_sha
    write_json(ready_path, payload)
    # final sha after including self
    ready_sha = sha256_file(ready_path)
    payload["artifact_digests"]["COLLECTOR_READY_TRADES_NOT_SCORED.json"] = ready_sha
    write_json(ready_path, payload)
    ready_sha = sha256_file(ready_path)

    # rebuild digests including READY
    digests2 = build_manifest_and_digests()
    # update READY artifact_digests with final DIGESTS/MANIFEST/STATUS
    payload["artifact_digests"] = {
        "COLLECTOR_READY_TRADES_NOT_SCORED.json": sha256_file(ready_path),  # will rewrite
        "STATUS.json": digests2.get("STATUS.json"),
        "CAPTURE_MANIFEST.json": digests2.get("CAPTURE_MANIFEST.json"),
        "DIGESTS.txt": digests2.get("DIGESTS.txt"),
        "requests.jsonl": digests2.get("requests.jsonl"),
        "http_429.jsonl": digests2.get("http_429.jsonl"),
    }
    # One more write: set READY sha to null placeholder then fix — simpler: omit self from map then add after
    write_json(ready_path, payload)
    ready_sha = sha256_file(ready_path)
    payload["artifact_digests"]["COLLECTOR_READY_TRADES_NOT_SCORED.json"] = ready_sha
    write_json(ready_path, payload)
    # This changes READY sha again — standard approach: leave self-sha as the sha BEFORE adding self,
    # OR don't include self. Spec says artifact_digests map for READY, STATUS, MANIFEST, DIGESTS, requests, http_429.
    # Include READY as sha of the file content that has the digests of the others (chicken-egg).
    # Final convention: write READY without self digest, hash it, then set self digest and accept that
    # the on-disk READY sha equals the self field only if we stop. Measured READY often lists others only.
    # Spec: "artifact_digests: sha256 map for READY, STATUS, MANIFEST, DIGESTS, requests.jsonl, http_429.jsonl"
    # We'll do: write without READY key, hash, add READY key with that hash, write once more,
    # and document that DIGESTS.txt / report use on-disk sha256 of final READY file.
    payload_final = dict(payload)
    ad = dict(payload["artifact_digests"])
    ad.pop("COLLECTOR_READY_TRADES_NOT_SCORED.json", None)
    payload_final["artifact_digests"] = ad
    write_json(ready_path, payload_final)
    ready_sha = sha256_file(ready_path)
    ad["COLLECTOR_READY_TRADES_NOT_SCORED.json"] = ready_sha
    payload_final["artifact_digests"] = ad
    write_json(ready_path, payload_final)
    # On-disk sha now differs from embedded self-sha; rebuild DIGESTS with final on-disk
    digests_final = build_manifest_and_digests()
    return ready_path


def stamp_incomplete(reason: str) -> Path:
    digests = build_manifest_and_digests()
    tickers_ok = []
    tickers_gap = []
    tickers_pending = []
    n_trades_total = 0
    n_empty = 0
    for t in TICKERS:
        info = STATE.per_ticker[t]
        n_trades_total += info["n_trades_total"]
        if info["status"] in ("ok", "empty_honest"):
            tickers_ok.append(t)
            if info["empty_honest"]:
                n_empty += 1
        elif info["status"] == "gap":
            tickers_gap.append({"ticker": t, "gap_reasons": list(info["gap_reasons"])})
        else:
            tickers_pending.append(t)
            tickers_gap.append({"ticker": t, "gap_reasons": list(info["gap_reasons"]) + ["incomplete_pending"]})

    path = ROOT / "INCOMPLETE_HONEST.json"
    payload = {
        "schema_id": "astra.q6s5_trades_fills.incomplete_honest.v0",
        "status": "INCOMPLETE_HONEST",
        "reason": reason,
        "series": SERIES,
        "packet_id": PACKET_ID,
        "kick_sha256": KICK_SHA_PIN,
        "accept_sha256": ACCEPT_SHA_PIN,
        "capture_root": CAPTURE_ROOT_REL,
        "start_utc": STATE.start_utc,
        "end_utc": utc_iso(),
        "n_tickers": 12,
        "tickers_ok": tickers_ok,
        "tickers_gap": tickers_gap,
        "tickers_pending": tickers_pending,
        "n_trades_total": n_trades_total,
        "n_empty_honest": n_empty,
        "n_200": STATE.n_200,
        "n_429": STATE.n_429,
        "n_other": STATE.n_other,
        "taker_fields_preserved": True,
        "lee_ready": False,
        "results": None,
        "pnl": None,
        "artifact_digests": {
            "STATUS.json": digests.get("STATUS.json"),
            "CAPTURE_MANIFEST.json": digests.get("CAPTURE_MANIFEST.json"),
            "DIGESTS.txt": digests.get("DIGESTS.txt"),
            "requests.jsonl": digests.get("requests.jsonl"),
            "http_429.jsonl": digests.get("http_429.jsonl"),
        },
        "note": "honest GET-only stop; empty≠invent; no READY stamped",
    }
    write_json(path, payload)
    build_manifest_and_digests()
    return path


def on_signal(signum: int, _frame: Any) -> None:
    print(f"[signal] got {signum}, stopping after current request", flush=True)
    STATE.stop = True


def main() -> int:
    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)

    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / "raw" / "trades").mkdir(parents=True, exist_ok=True)
    (ROOT / "per_ticker").mkdir(parents=True, exist_ok=True)

    # truncate jsonl logs for this run
    for name in ("requests.jsonl", "http_429.jsonl"):
        p = ROOT / name
        if p.exists():
            p.write_text("", encoding="utf-8")

    verify_pins()
    write_json(ROOT / "kick_pin.json", {
        "id": "CONDUCTOR_KICK_COLLECTOR_Q6S5_KXMLBSPREAD_TRADES_FILLS",
        "kick_sha256": KICK_SHA_PIN,
        "accept_sha256": ACCEPT_SHA_PIN,
        "tickers": TICKERS,
        "stamped_at_utc": utc_iso(),
        "packet_id": PACKET_ID,
        "series": SERIES,
    })

    STATE.phase = "CAPTURING"
    update_status()
    print(f"[start] {STATE.start_utc} n_tickers=12 min_gap={MIN_GAP_S}s", flush=True)

    for ticker in TICKERS:
        if STATE.stop or wall_exceeded():
            print("[stop] wall/stop before remaining tickers", flush=True)
            break
        try:
            capture_ticker(ticker)
        except Exception as e:
            print(f"[error] {ticker}: {e}\n{traceback.format_exc()}", flush=True)
            info = STATE.per_ticker[ticker]
            info["status"] = "gap"
            info["gap_reasons"].append(f"exception:{type(e).__name__}:{e}")
            write_json(ROOT / "per_ticker" / f"{ticker}.json", {
                "ticker": ticker,
                "http_outcomes": info["http_outcomes"],
                "n_pages": info["n_pages"],
                "n_trades_total": info["n_trades_total"],
                "empty_honest": False,
                "first_created_time": info["first_created_time"],
                "last_created_time": info["last_created_time"],
                "taker_field_keys_observed": info["taker_field_keys_observed"],
                "gap_reasons": list(info["gap_reasons"]),
                "status": "gap",
            })

    # Resolve readiness
    all_resolved = all(
        STATE.per_ticker[t]["status"] in ("ok", "empty_honest", "gap")
        for t in TICKERS
    )
    # READY only when all 12 resolved (ok/empty OR durable gap). Spec says stamp READY when all resolved
    # including durable gaps. So READY if all_resolved.
    # But if wall stop left pending, INCOMPLETE.
    if all_resolved:
        STATE.phase = "READY"
        update_status()
        digests = build_manifest_and_digests()
        ready_path = stamp_ready(digests)
        print(f"[done] READY {ready_path} sha={sha256_file(ready_path)}", flush=True)
        return 0
    else:
        reason = "wall_or_stop_incomplete"
        if GOV.in_storm or STATE.n_429 >= 3:
            reason = "PAUSE_429_STORM_or_persistent_429_incomplete"
        STATE.phase = "INCOMPLETE_HONEST"
        update_status()
        path = stamp_incomplete(reason)
        print(f"[done] INCOMPLETE_HONEST {path} sha={sha256_file(path)}", flush=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
