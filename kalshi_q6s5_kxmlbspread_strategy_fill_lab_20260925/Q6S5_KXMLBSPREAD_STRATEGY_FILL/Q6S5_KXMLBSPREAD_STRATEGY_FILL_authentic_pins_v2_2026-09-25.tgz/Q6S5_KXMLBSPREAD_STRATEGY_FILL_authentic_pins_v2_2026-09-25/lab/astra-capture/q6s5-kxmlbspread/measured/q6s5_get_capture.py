#!/usr/bin/env python3
"""Q6S5 KXMLBSPREAD GET-only measured capture poller (Astra Collector).

Hard rules:
- GET-only public Kalshi API
- Series KXMLBSPREAD only
- Honor 429: backoff, log gap, never invent/fill/retry-burst
- Spacing: <=3 rpm, >=20s between GETs; after 429 +2s for 30min;
  >=3x429 in 10min -> pause 10min PAUSE_429_STORM
- No orders, no admit.py, no scoring, no PnL invention
- Fee observation labeled CACHE (never claim R1-P1)
- Do not touch ADMIT-1 recorder
"""
from __future__ import annotations

import hashlib
import json
import os
import signal
import sys
import time
import traceback
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE = "https://api.elections.kalshi.com/trade-api/v2"
ROOT = Path(__file__).resolve().parent
PANEL_PATH = ROOT.parent / "panel_admitted.json"
KICK_PATH = Path(
    "/workspace/lab/governance/astra/packets/"
    "CONDUCTOR_KICK_COLLECTOR_Q6S5_KXMLBSPREAD_GET_CAPTURE_2026-09-25.json"
)
PANEL_SHA_PIN = "e36de2d1ce6286dff90d25f2fae680170c8a469c443c1beed974ffe80383fba1"
KICK_SHA_PIN = "83cc234ca1ee511bd38fb3041cb79c99f9d9bdd6a24b7467600884a56f979cb6"

MIN_GAP_S = 20.0
RPM_CAP = 3.0
AFTER_429_EXTRA_S = 2.0
AFTER_429_WINDOW_S = 30 * 60
STORM_N = 3
STORM_WINDOW_S = 10 * 60
STORM_PAUSE_S = 10 * 60
MAX_RUNTIME_S = 6 * 3600
CYCLE_IDLE_TARGET_S = 60.0  # small idle between cycles; cycle itself ~8-10min
USER_AGENT = "AstraCollector-Q6S5-KXMLBSPREAD-GET/1.0"

SETTLED_STATUSES = {"finalized", "determined", "settled"}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_iso(dt: Optional[datetime] = None) -> str:
    d = dt or utc_now()
    return d.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def write_json(path: Path, obj: Any) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(obj, indent=2, sort_keys=False) + "\n"
    path.write_text(raw, encoding="utf-8")
    return sha256_bytes(raw.encode("utf-8"))


def append_jsonl(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, separators=(",", ":")) + "\n")


def load_panel() -> Tuple[List[str], List[str], Dict[str, Any]]:
    panel = json.loads(PANEL_PATH.read_text(encoding="utf-8"))
    events = [r["event_ticker"] for r in panel["subset_selection"]["rows"]]
    markets: List[str] = []
    for r in panel["subset_selection"]["rows"]:
        markets.extend(r["picked_tickers"])
    assert len(events) == 6 and len(markets) == 12
    return events, markets, panel


class RateGovernor:
    def __init__(self) -> None:
        self.min_gap = MIN_GAP_S
        self.last_get_mono: Optional[float] = None
        self.extra_until_mono: float = 0.0
        self.recent_429: List[float] = []
        self.pause_until_mono: float = 0.0
        self.in_storm = False

    def note_429(self) -> None:
        now = time.monotonic()
        self.recent_429.append(now)
        self.extra_until_mono = max(self.extra_until_mono, now + AFTER_429_WINDOW_S)
        cutoff = now - STORM_WINDOW_S
        self.recent_429 = [t for t in self.recent_429 if t >= cutoff]
        if len(self.recent_429) >= STORM_N:
            self.pause_until_mono = max(self.pause_until_mono, now + STORM_PAUSE_S)
            self.in_storm = True

    def wait_before_get(self) -> Dict[str, Any]:
        meta: Dict[str, Any] = {"paused": False, "storm": False, "wait_s": 0.0}
        now = time.monotonic()
        if now < self.pause_until_mono:
            sleep_s = self.pause_until_mono - now
            meta.update({"paused": True, "storm": True, "wait_s": sleep_s, "reason": "PAUSE_429_STORM"})
            time.sleep(sleep_s)
            now = time.monotonic()
            self.in_storm = False
        gap = self.min_gap
        if now < self.extra_until_mono:
            gap = self.min_gap + AFTER_429_EXTRA_S
        if self.last_get_mono is not None:
            elapsed = now - self.last_get_mono
            if elapsed < gap:
                wait = gap - elapsed
                meta["wait_s"] = wait
                time.sleep(wait)
        self.last_get_mono = time.monotonic()
        return meta


class CaptureState:
    def __init__(self) -> None:
        self.start_utc = utc_iso()
        self.start_mono = time.monotonic()
        self.n_polls = 0
        self.n_200 = 0
        self.n_429 = 0
        self.n_other = 0
        self.fee_obs: Optional[Dict[str, Any]] = None
        self.first_cycle: Optional[Dict[str, Any]] = None
        self.phase = "STARTING"
        self.stop = False
        self.gaps: List[Dict[str, Any]] = []
        # ticker -> whether we ever got honest 200 for market AND orderbook
        self.market_ok: Dict[str, bool] = {}
        self.orderbook_ok: Dict[str, bool] = {}
        self.event_ok: Dict[str, bool] = {}
        self.series_ok = False
        self.settled_markets: Dict[str, str] = {}
        self.last_cycle_summary: Optional[Dict[str, Any]] = None


STATE = CaptureState()
GOV = RateGovernor()


def update_status(**extra: Any) -> None:
    elapsed = time.monotonic() - STATE.start_mono
    payload: Dict[str, Any] = {
        "schema_id": "astra.q6s5_get_capture.status.v0",
        "series": "KXMLBSPREAD",
        "packet_id": "Q6S5-KXMLBSPREAD-FEEQUEUE-HARNESS",
        "phase": STATE.phase,
        "start_utc": STATE.start_utc,
        "updated_utc": utc_iso(),
        "elapsed_s": round(elapsed, 1),
        "n_polls": STATE.n_polls,
        "n_200": STATE.n_200,
        "n_429": STATE.n_429,
        "n_other": STATE.n_other,
        "fee_observation": STATE.fee_obs,
        "fee_label": "CACHE",
        "fee_claim_as_live_R1P1": False,
        "panel_sha256": PANEL_SHA_PIN,
        "kick_sha256": KICK_SHA_PIN,
        "first_cycle": STATE.first_cycle,
        "coverage": {
            "series_ok": STATE.series_ok,
            "events_ok_n": sum(1 for v in STATE.event_ok.values() if v),
            "events_total": 6,
            "markets_ok_n": sum(1 for v in STATE.market_ok.values() if v),
            "markets_total": 12,
            "orderbooks_ok_n": sum(1 for v in STATE.orderbook_ok.values() if v),
            "orderbooks_total": 12,
        },
        "settled_markets": STATE.settled_markets,
        "gaps_n": len(STATE.gaps),
        "last_cycle": STATE.last_cycle_summary,
        "results": None,
        "pnl": None,
        "rules": [
            "GET_only",
            "no_orders",
            "no_admit",
            "no_score",
            "no_invent",
            "fee_CACHE_not_R1P1",
            "ADMIT1_untouched",
        ],
    }
    payload.update(extra)
    write_json(ROOT / "STATUS.json", payload)


def rebuild_digests() -> None:
    lines: List[str] = []
    lines.append(f"# Q6S5 KXMLBSPREAD measured DIGESTS  updated={utc_iso()}")
    lines.append(f"# panel_admitted.json  {PANEL_SHA_PIN}")
    lines.append(f"# kick                {KICK_SHA_PIN}")
    durable = []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        if p.name == "DIGESTS.txt":
            continue
        if p.name.endswith(".pid"):
            continue
        if p.name.endswith(".log"):
            # include log digests too for honesty
            pass
        rel = p.relative_to(ROOT).as_posix()
        digest = sha256_file(p)
        lines.append(f"{digest}  {rel}")
        durable.append((rel, digest))
    (ROOT / "DIGESTS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def do_get(path: str, kind: str, key: str, cycle: int) -> Tuple[int, Optional[bytes], Dict[str, Any]]:
    """Perform one GET with spacing. Returns (status, body_or_None, meta)."""
    wait_meta = GOV.wait_before_get()
    if wait_meta.get("paused"):
        STATE.phase = "PAUSE_429_STORM"
        update_status()
        append_jsonl(
            ROOT / "requests.jsonl",
            {
                "ts_utc": utc_iso(),
                "cycle": cycle,
                "kind": "pause",
                "reason": "PAUSE_429_STORM",
                "wait_s": wait_meta.get("wait_s"),
            },
        )
        STATE.phase = "POLLING"

    url = f"{BASE}{path}"
    req = Request(url, method="GET", headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    ts = utc_iso()
    t0 = time.monotonic()
    status = -1
    body: Optional[bytes] = None
    err: Optional[str] = None
    try:
        with urlopen(req, timeout=30) as resp:
            status = int(resp.status)
            body = resp.read()
    except HTTPError as e:
        status = int(e.code)
        try:
            body = e.read()
        except Exception:
            body = None
        err = f"HTTPError:{status}"
    except URLError as e:
        err = f"URLError:{e.reason}"
        status = -1
    except Exception as e:
        err = f"{type(e).__name__}:{e}"
        status = -1
    elapsed_ms = int((time.monotonic() - t0) * 1000)

    rec = {
        "ts_utc": ts,
        "cycle": cycle,
        "kind": kind,
        "key": key,
        "method": "GET",
        "path": path,
        "url": url,
        "http": status,
        "elapsed_ms": elapsed_ms,
        "bytes": len(body) if body is not None else 0,
        "err": err,
        "wait_meta": wait_meta,
    }
    append_jsonl(ROOT / "requests.jsonl", rec)

    if status == 200:
        STATE.n_200 += 1
    elif status == 429:
        STATE.n_429 += 1
        GOV.note_429()
        gap = {
            "ts_utc": ts,
            "cycle": cycle,
            "kind": kind,
            "key": key,
            "path": path,
            "http": 429,
            "honored": True,
            "no_retry_burst": True,
            "extra_gap_s": AFTER_429_EXTRA_S,
            "extra_window_s": AFTER_429_WINDOW_S,
        }
        append_jsonl(ROOT / "http_429.jsonl", gap)
        STATE.gaps.append(gap)
    else:
        STATE.n_other += 1
        if status != 200:
            STATE.gaps.append(
                {
                    "ts_utc": ts,
                    "cycle": cycle,
                    "kind": kind,
                    "key": key,
                    "path": path,
                    "http": status,
                    "err": err,
                    "honored": True,
                }
            )

    return status, body, rec


def save_raw(subdir: str, name: str, body: bytes, cycle: int, http: int) -> Path:
    day = utc_now().strftime("%Y-%m-%d")
    # dated filename with cycle stamp for uniqueness; also keep latest soft name
    stamp = utc_now().strftime("%Y%m%dT%H%M%SZ")
    d = ROOT / "raw" / subdir
    d.mkdir(parents=True, exist_ok=True)
    dated = d / f"{day}__c{cycle:04d}__{stamp}__{name}.json"
    dated.write_bytes(body)
    # latest pointer (overwrite)
    latest = d / f"{name}.json"
    latest.write_bytes(body)
    meta = {
        "saved_utc": utc_iso(),
        "cycle": cycle,
        "http": http,
        "sha256": sha256_bytes(body),
        "dated_rel": dated.relative_to(ROOT).as_posix(),
        "latest_rel": latest.relative_to(ROOT).as_posix(),
        "bytes": len(body),
    }
    (d / f"{name}.meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return dated


def run_cycle(cycle: int, events: List[str], markets: List[str], do_series: bool) -> Dict[str, Any]:
    summary: Dict[str, Any] = {
        "cycle": cycle,
        "start_utc": utc_iso(),
        "do_series": do_series,
        "counts": {"200": 0, "429": 0, "other": 0},
        "series": None,
        "events": {},
        "markets": {},
        "orderbooks": {},
        "gaps": [],
    }
    STATE.phase = "POLLING"
    update_status()

    if do_series:
        st, body, _ = do_get("/series/KXMLBSPREAD", "series", "KXMLBSPREAD", cycle)
        summary["series"] = {"http": st}
        if st == 200 and body:
            summary["counts"]["200"] += 1
            save_raw("series", "KXMLBSPREAD", body, cycle, st)
            STATE.series_ok = True
            try:
                parsed = json.loads(body.decode("utf-8"))
                series = parsed.get("series") or parsed
                fee_type = series.get("fee_type")
                fee_mult = series.get("fee_multiplier")
                STATE.fee_obs = {
                    "source": "GET /series/KXMLBSPREAD",
                    "observed_fee_type": fee_type,
                    "observed_fee_multiplier": fee_mult,
                    "label": "CACHE",
                    "claim_as_live_R1P1": False,
                    "note": "CACHE×0.5 until Examiner live /series pin — observed values recorded, not claimed R1-P1",
                    "observed_at_utc": utc_iso(),
                }
            except Exception as e:
                STATE.fee_obs = {
                    "source": "GET /series/KXMLBSPREAD",
                    "parse_error": str(e),
                    "label": "CACHE",
                    "claim_as_live_R1P1": False,
                }
        elif st == 429:
            summary["counts"]["429"] += 1
            summary["gaps"].append({"kind": "series", "http": 429})
        else:
            summary["counts"]["other"] += 1
            summary["gaps"].append({"kind": "series", "http": st})

    for et in events:
        # Prefer nested markets on event
        path = f"/events/{et}?with_nested_markets=true"
        st, body, _ = do_get(path, "event", et, cycle)
        summary["events"][et] = {"http": st, "path": path}
        if st == 200 and body:
            summary["counts"]["200"] += 1
            save_raw("events", et, body, cycle, st)
            STATE.event_ok[et] = True
        elif st == 429:
            summary["counts"]["429"] += 1
            summary["gaps"].append({"kind": "event", "key": et, "http": 429})
            # try without query as honest alternate (still one GET, already logged 429 — NO retry burst)
            # do NOT immediately retry; leave gap
        elif st == 400 or st == 404:
            # maybe query unsupported — single alternate attempt after normal spacing (not a burst)
            path2 = f"/events/{et}"
            st2, body2, _ = do_get(path2, "event", et, cycle)
            summary["events"][et] = {"http": st2, "path": path2, "fallback_from": st}
            if st2 == 200 and body2:
                summary["counts"]["200"] += 1
                summary["counts"]["other"] += 1  # count original failure
                save_raw("events", et, body2, cycle, st2)
                STATE.event_ok[et] = True
            elif st2 == 429:
                summary["counts"]["429"] += 1
                summary["counts"]["other"] += 1
                summary["gaps"].append({"kind": "event", "key": et, "http": 429})
            else:
                summary["counts"]["other"] += 2
                summary["gaps"].append({"kind": "event", "key": et, "http": st2})
        else:
            summary["counts"]["other"] += 1
            summary["gaps"].append({"kind": "event", "key": et, "http": st})

    for mt in markets:
        path = f"/markets/{mt}"
        st, body, _ = do_get(path, "market", mt, cycle)
        summary["markets"][mt] = {"http": st}
        if st == 200 and body:
            summary["counts"]["200"] += 1
            save_raw("markets", mt, body, cycle, st)
            STATE.market_ok[mt] = True
            try:
                parsed = json.loads(body.decode("utf-8"))
                m = parsed.get("market") or parsed
                status_s = (m.get("status") or "").lower()
                result = m.get("result") or ""
                if status_s in SETTLED_STATUSES or result in ("yes", "no"):
                    STATE.settled_markets[mt] = status_s or f"result:{result}"
            except Exception:
                pass
        elif st == 429:
            summary["counts"]["429"] += 1
            summary["gaps"].append({"kind": "market", "key": mt, "http": 429})
        else:
            summary["counts"]["other"] += 1
            summary["gaps"].append({"kind": "market", "key": mt, "http": st})

        # orderbook
        path_ob = f"/markets/{mt}/orderbook?depth=10"
        st_ob, body_ob, _ = do_get(path_ob, "orderbook", mt, cycle)
        summary["orderbooks"][mt] = {"http": st_ob}
        if st_ob == 200 and body_ob:
            summary["counts"]["200"] += 1
            save_raw("orderbooks", mt, body_ob, cycle, st_ob)
            STATE.orderbook_ok[mt] = True
        elif st_ob == 429:
            summary["counts"]["429"] += 1
            summary["gaps"].append({"kind": "orderbook", "key": mt, "http": 429})
        else:
            summary["counts"]["other"] += 1
            summary["gaps"].append({"kind": "orderbook", "key": mt, "http": st_ob})

    summary["end_utc"] = utc_iso()
    summary["coverage_snapshot"] = {
        "series_ok": STATE.series_ok,
        "events_ok": dict(STATE.event_ok),
        "markets_ok": dict(STATE.market_ok),
        "orderbooks_ok": dict(STATE.orderbook_ok),
    }
    out = ROOT / "polls" / f"cycle_{cycle:04d}.json"
    write_json(out, summary)
    STATE.n_polls = cycle
    STATE.last_cycle_summary = {
        "cycle": cycle,
        "start_utc": summary["start_utc"],
        "end_utc": summary["end_utc"],
        "counts": summary["counts"],
        "gaps_n": len(summary["gaps"]),
    }
    if cycle == 1:
        STATE.first_cycle = {
            "start_utc": summary["start_utc"],
            "end_utc": summary["end_utc"],
            "n_200": summary["counts"]["200"],
            "n_429": summary["counts"]["429"],
            "n_other": summary["counts"]["other"],
            "series_http": (summary["series"] or {}).get("http"),
            "events_200": sum(1 for v in summary["events"].values() if v.get("http") == 200),
            "markets_200": sum(1 for v in summary["markets"].values() if v.get("http") == 200),
            "orderbooks_200": sum(1 for v in summary["orderbooks"].values() if v.get("http") == 200),
        }
    update_status()
    rebuild_digests()
    return summary


def honest_full_sweep() -> bool:
    """At least one honest measured 200 for series + all 6 events + all 12 markets + all 12 orderbooks."""
    if not STATE.series_ok:
        return False
    if sum(1 for v in STATE.event_ok.values() if v) < 6:
        return False
    if sum(1 for v in STATE.market_ok.values() if v) < 12:
        return False
    if sum(1 for v in STATE.orderbook_ok.values() if v) < 12:
        return False
    return True


def gap_list() -> List[Dict[str, Any]]:
    missing = []
    if not STATE.series_ok:
        missing.append({"kind": "series", "key": "KXMLBSPREAD"})
    for et in ["KXMLBSPREAD-26SEP242140HOUATH", "KXMLBSPREAD-26SEP242140LAASEA",
               "KXMLBSPREAD-26SEP242210SDLAD", "KXMLBSPREAD-26SEP251840PITDET",
               "KXMLBSPREAD-26SEP251840TBPHI", "KXMLBSPREAD-26SEP251845NYMWSH"]:
        if not STATE.event_ok.get(et):
            missing.append({"kind": "event", "key": et})
    # markets from panel will be passed; rebuild from STATE keys expected
    return missing


def write_terminal(kind: str, events: List[str], markets: List[str]) -> Path:
    """kind in READY_NOT_SCORED | INCOMPLETE_HONEST"""
    gaps = []
    if not STATE.series_ok:
        gaps.append({"kind": "series", "key": "KXMLBSPREAD"})
    for et in events:
        if not STATE.event_ok.get(et):
            gaps.append({"kind": "event", "key": et})
    for mt in markets:
        if not STATE.market_ok.get(mt):
            gaps.append({"kind": "market", "key": mt})
        if not STATE.orderbook_ok.get(mt):
            gaps.append({"kind": "orderbook", "key": mt})

    # digests of key artifacts
    key_paths = [
        ROOT / "CAPTURE_MANIFEST.json",
        ROOT / "STATUS.json",
        ROOT / "requests.jsonl",
        ROOT / "http_429.jsonl",
        ROOT / "DIGESTS.txt",
    ]
    digests = {}
    for p in key_paths:
        if p.exists():
            digests[p.name] = sha256_file(p)

    payload = {
        "schema_id": f"astra.q6s5_get_capture.{kind.lower()}.v0",
        "status": kind,
        "series": "KXMLBSPREAD",
        "packet_id": "Q6S5-KXMLBSPREAD-FEEQUEUE-HARNESS",
        "arms": {"Q6S5A0": "maker_vs_taker_native", "Q6S5A1": "content_fresh_vs_stale_bin"},
        "panel_sha256": PANEL_SHA_PIN,
        "kick_sha256": KICK_SHA_PIN,
        "start_utc": STATE.start_utc,
        "end_utc": utc_iso(),
        "n_polls": STATE.n_polls,
        "n_200": STATE.n_200,
        "n_429": STATE.n_429,
        "n_other": STATE.n_other,
        "fee_observation": STATE.fee_obs,
        "fee_label": "CACHE",
        "fee_claim_as_live_R1P1": False,
        "first_cycle": STATE.first_cycle,
        "coverage": {
            "series_ok": STATE.series_ok,
            "events_ok_n": sum(1 for et in events if STATE.event_ok.get(et)),
            "markets_ok_n": sum(1 for mt in markets if STATE.market_ok.get(mt)),
            "orderbooks_ok_n": sum(1 for mt in markets if STATE.orderbook_ok.get(mt)),
            "events_total": len(events),
            "markets_total": len(markets),
            "orderbooks_total": len(markets),
            "honest_full_sweep": honest_full_sweep(),
        },
        "gaps": gaps,
        "settled_markets": STATE.settled_markets,
        "artifact_digests": digests,
        "results": None,
        "pnl": None,
        "note": (
            "Honest GET-only measured capture. 429 gaps logged, never invented. "
            "Fee labeled CACHE — not live R1-P1. Examiner owns SCORE."
        ),
    }
    out = ROOT / f"{kind}.json"
    write_json(out, payload)
    STATE.phase = kind
    update_status(terminal=kind, terminal_path=out.name)
    rebuild_digests()
    # refresh digests inside terminal file for DIGESTS.txt itself
    if (ROOT / "DIGESTS.txt").exists():
        digests["DIGESTS.txt"] = sha256_file(ROOT / "DIGESTS.txt")
        digests["STATUS.json"] = sha256_file(ROOT / "STATUS.json")
        payload["artifact_digests"] = digests
        write_json(out, payload)
        rebuild_digests()
    return out


def all_markets_settled(markets: List[str]) -> bool:
    return all(mt in STATE.settled_markets for mt in markets)


def handle_signal(signum: int, _frame: Any) -> None:
    STATE.stop = True
    STATE.phase = f"SIGNAL_{signum}"
    update_status()


def main() -> int:
    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    events, markets, panel = load_panel()
    got_panel_sha = sha256_file(PANEL_PATH)
    got_kick_sha = sha256_file(KICK_PATH) if KICK_PATH.exists() else None
    if got_panel_sha != PANEL_SHA_PIN:
        print(f"FATAL panel sha mismatch {got_panel_sha} != {PANEL_SHA_PIN}", file=sys.stderr)
        return 2
    if got_kick_sha != KICK_SHA_PIN:
        print(f"FATAL kick sha mismatch {got_kick_sha} != {KICK_SHA_PIN}", file=sys.stderr)
        return 2

    for mt in markets:
        STATE.market_ok.setdefault(mt, False)
        STATE.orderbook_ok.setdefault(mt, False)
    for et in events:
        STATE.event_ok.setdefault(et, False)

    manifest = {
        "schema_id": "astra.q6s5_get_capture.manifest.v0",
        "series": "KXMLBSPREAD",
        "packet_id": "Q6S5-KXMLBSPREAD-FEEQUEUE-HARNESS",
        "panel_sha256": PANEL_SHA_PIN,
        "kick_sha256": KICK_SHA_PIN,
        "accept_admit_sha256": "64ea00aa682b191d4bd3d39264389e5d813b9b8ae3883ac4337ee258925ab501",
        "panel_path": str(PANEL_PATH),
        "kick_path": str(KICK_PATH),
        "start_utc": STATE.start_utc,
        "arms": {
            "Q6S5A0": "maker_vs_taker_native",
            "Q6S5A1": "content_fresh_vs_stale_bin",
        },
        "api_base": BASE,
        "spacing_policy": {
            "max_rpm": RPM_CAP,
            "min_gap_s": MIN_GAP_S,
            "after_429_extra_s": AFTER_429_EXTRA_S,
            "after_429_window_s": AFTER_429_WINDOW_S,
            "storm_n": STORM_N,
            "storm_window_s": STORM_WINDOW_S,
            "storm_pause_s": STORM_PAUSE_S,
            "prefer_quieter_than_mechanic": True,
        },
        "runtime_policy": {
            "max_runtime_s": MAX_RUNTIME_S,
            "stop_when": "all_12_markets_settled OR 6h elapsed",
            "terminal_ready": "READY_NOT_SCORED if honest full sweep of all 12 tickers (429 gaps OK)",
            "terminal_incomplete": "INCOMPLETE_HONEST with gap list if still thin",
        },
        "events": events,
        "markets": markets,
        "fee_policy": {
            "label": "CACHE",
            "expected_cache": {"fee_type": "quadratic", "fee_multiplier": 0.5},
            "claim_as_live_R1P1": False,
            "note": "Record observed from GET /series/KXMLBSPREAD but label CACHE until Examiner live pin",
        },
        "refuse": ["orders", "admit.py", "score", "invent", "PnL", "touch_ADMIT1"],
        "results": None,
        "pnl": None,
    }
    write_json(ROOT / "CAPTURE_MANIFEST.json", manifest)
    # touch empty jsonl
    (ROOT / "requests.jsonl").touch()
    (ROOT / "http_429.jsonl").touch()
    STATE.phase = "MANIFEST_WRITTEN"
    update_status()
    rebuild_digests()

    cycle = 0
    terminal_written = False
    try:
        while not STATE.stop:
            elapsed = time.monotonic() - STATE.start_mono
            if elapsed >= MAX_RUNTIME_S:
                break
            if cycle >= 1 and all_markets_settled(markets):
                break

            cycle += 1
            do_series = cycle == 1
            print(f"[{utc_iso()}] starting cycle {cycle} do_series={do_series}", flush=True)
            run_cycle(cycle, events, markets, do_series=do_series)
            print(
                f"[{utc_iso()}] cycle {cycle} done "
                f"200={STATE.last_cycle_summary['counts']['200']} "
                f"429={STATE.last_cycle_summary['counts']['429']} "
                f"other={STATE.last_cycle_summary['counts']['other']}",
                flush=True,
            )

            # After first full attempt: if still thin and we somehow can't continue, mark incomplete later.
            # Keep polling until settle or 6h.
            if all_markets_settled(markets):
                break
            if time.monotonic() - STATE.start_mono >= MAX_RUNTIME_S:
                break
            if STATE.stop:
                break

            # Idle between cycles (cycle itself already ~10min at 20s spacing)
            time.sleep(CYCLE_IDLE_TARGET_S)
    except Exception:
        STATE.phase = "ERROR"
        update_status(error=traceback.format_exc())
        rebuild_digests()
        raise

    # Terminal decision
    if honest_full_sweep():
        write_terminal("READY_NOT_SCORED", events, markets)
    else:
        # Still ping-worthy incomplete honest
        write_terminal("INCOMPLETE_HONEST", events, markets)
    print(f"[{utc_iso()}] terminal phase={STATE.phase} n_polls={STATE.n_polls} n_429={STATE.n_429}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
