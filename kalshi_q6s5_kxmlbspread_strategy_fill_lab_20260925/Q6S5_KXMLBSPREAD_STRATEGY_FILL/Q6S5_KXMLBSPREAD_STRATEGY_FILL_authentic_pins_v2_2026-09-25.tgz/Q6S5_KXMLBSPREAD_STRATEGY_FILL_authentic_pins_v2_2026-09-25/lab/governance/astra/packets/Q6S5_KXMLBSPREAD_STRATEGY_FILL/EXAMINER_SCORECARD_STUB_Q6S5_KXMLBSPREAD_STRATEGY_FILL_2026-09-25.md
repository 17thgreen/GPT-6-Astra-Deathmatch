# EXAMINER SCORECARD STUB — Q6S5-KXMLBSPREAD-STRATEGY-FILL (drafted by Variants; stamped 2026-09-29T16:52:00-04:00)

**Status:** HOLD_PRE_PR · stub_ready=false · scored=false · verdict null · all metrics **null** (measured=false)  
**Template:** EXAMINER_KALSHI_SCORECARD_TEMPLATE v1.2 · sha256 `56bcf6269a42031d9d90496e9a65c2292321aed2165033f6fb44ff8cc4d6b1cc`  
**Freeze:** sha256 `9f50ba19694083c774bbe2a6cff491d1a2f81ed3a6f9cc21a3641a938c84955d`  
**Knob:** fill_model ∈ {public_trade_through_conservative (AVAILABLE; MODEL; simulated_fills; counts_toward_keep=false), mechanic_demo_observed (UNAVAILABLE)}  
**Arms:** Q6S5A0 maker_vs_taker_native · Q6S5A1 content_fresh_vs_stale_bin  
**Fee:** CACHE_NOT_R1P1 (FEE_PIN `9c0f3554…` formula_id absent) — not R1-P1  
**ADMIT-1 gap:** ruling `ac7cfe63…` pinned; exclusion window [2026-09-27T00:00Z, 2026-09-30T04:00Z) enforced; excluded_admit1_window_n null  
**p16:** satisfied 11 / n/a 0 / missing 1 (item 12)  
**Refuse:** invent fills/PnL · Lee-Ready · live orders · CACHE as R1-P1 · S1/Q6-000/Cap-SR/Q6S1 retune · Refiner · simulated fills toward KEEP  

Full null schema: `EMPTY_RESULTS.json` → `examiner_scorecard_v1_2`, and `EXAMINER_HOLD_Q6S5_KXMLBSPREAD_STRATEGY_FILL_PRE_PR_2026-09-25.json`.
