# R3-P2 Mechanic — Demo trade-step + fill-label series — 2026-09-23 (ET)

**Seat:** The Mechanic (Execution Engineer)  
**Packet:** R3-P2-QUEUE-POSITION-CALIB  
**Protocol:** `R3_P2_TRADE_STEP_FILL_LABEL_v1`  
**Hard rules:** Demo host only (`https://demo-api.kalshi.co`). Funded ei=0 only. Cancel-safe. No live. No invent metrics. Frozen knobs sha256 `9a353421…` not retuned. Metrics null.

## Timestamp
- **ET start:** `2026-09-23T17:41:06.786203-04:00`
- **ET end:** `2026-09-23T17:54:29.898748-04:00`
- Written: `2026-09-23T17:54:29.901674-04:00`

## Summary
| Metric | Value |
|--------|-------|
| N attempted | 14 |
| N success | 12 |
| leftover_resting | **no** |
| success with trade_size_observed > 0 | 0 |
| success with fill_binary=1 | 0 |
| success with qp_t0 ≥ 10 | 8 |
| hold_window_s | 45 |
| poll_interval_s | 5 |
| series file sha256 (on disk, authoritative) | `6e2c82570e72efd19c4c77cac01c8727965938dfbceefec7a8a7d2f2db667db1` |
| embedded meta.series_sha256 (pre-embed content hash, NOT the file sha) | `da80afa3aa9809f13089144ee4a40fe153ddedd6b1291cb1200d846590abb089` |
| host | `https://demo-api.kalshi.co` |

## Auth smoke
- `GET /trade-api/v2/portfolio/balance` → **HTTP 200**
- funded_shards: `{0: 100.0, 1: 0.0, 2: 0.0, 3: 0.0}`

## Markets discovered (ei=0)
- `KXNFLGAME-26SEP24ATLGB-GB`
- `KXNFLSPREAD-26SEP28PHICHI-PHI15`
- `KXNFLGAME-26SEP27KCMIA-KC`
- `KXNFLGAME-26SEP27KCMIA-MIA`
- `KXNFLGAME-26SEP24ATLGB-ATL`
- `KXNFLSPREAD-26SEP28PHICHI-CHI10`
- `KXNFLSPREAD-26SEP28PHICHI-PHI8`
- `KXNFLSPREAD-26SEP28PHICHI-PHI7`
- `KXNFLGAME-26OCT04INDWAS-IND`
- `KXNFLGAME-26SEP27CARCLE-CAR`
- `KXNFLGAME-26OCT04NEBUF-NE`
- `KXNFLGAME-26OCT04DENSF-DEN`
- `KXNFLGAME-26OCT04DALHOU-HOU`
- `KXNFLGAME-26OCT04LARPHI-LAR`
- `KXNFLGAME-26OCT04GBTB-TB`
- `KXNFLGAME-26SEP27NEJAC-JAC`
- `KXNFLGAME-26SEP27NYJDET-DET`
- `KXNFLGAME-26OCT04DETCAR-CAR`
- `KXNFLGAME-26OCT04NEBUF-BUF`
- `KXNFLGAME-26OCT05ATLNO-ATL`
- `KXNFLGAME-26OCT04NYJCHI-NYJ`
- `KXNFLGAME-26OCT04JACCIN-JAC`
- `KXNFLGAME-26OCT04DALHOU-DAL`
- `KXNFLGAME-26SEP27HOUIND-IND`
- `KXNFLGAME-26OCT04KCLV-LV`
- `KXNFLGAME-26OCT01PITCLE-PIT`
- `KXNFLSPREAD-26SEP28PHICHI-PHI11`
- `KXNFLGAME-26OCT04GBTB-GB`
- `KXNFLGAME-26OCT04LARPHI-PHI`
- `KXNFLGAME-26OCT04INDWAS-WAS`
- `KXNFLGAME-26OCT04ARINYG-ARI`
- `KXNFLGAME-26OCT04NYJCHI-CHI`
- `KXNFLGAME-26OCT04TENBAL-TEN`
- `KXNFLGAME-26OCT04MIAMIN-MIN`
- `KXNFLGAME-26OCT04DENSF-SF`
- `KXNFLGAME-26OCT04LACSEA-SEA`
- `KXNFLGAME-26OCT04DETCAR-DET`
- `KXNFLGAME-26OCT05ATLNO-NO`
- `KXNFLGAME-26SEP27CARCLE-CLE`
- `KXNFLGAME-26SEP27CINPIT-PIT`

## Tickers used (success)
- `KXNFLGAME-26OCT04DALHOU-HOU`
- `KXNFLGAME-26OCT04INDWAS-IND`
- `KXNFLGAME-26OCT04LARPHI-LAR`
- `KXNFLGAME-26SEP24ATLGB-ATL`
- `KXNFLGAME-26SEP24ATLGB-GB`
- `KXNFLGAME-26SEP27CARCLE-CAR`
- `KXNFLGAME-26SEP27KCMIA-KC`
- `KXNFLGAME-26SEP27KCMIA-MIA`
- `KXNFLSPREAD-26SEP28PHICHI-CHI10`
- `KXNFLSPREAD-26SEP28PHICHI-PHI15`
- `KXNFLSPREAD-26SEP28PHICHI-PHI7`
- `KXNFLSPREAD-26SEP28PHICHI-PHI8`

## Limit prices used
`['0.0100']`

## Cancel / leftover
- End-of-run resting list HTTP: `200`
- Resting order ids: `[]`
- Our leftover canceled: `[{'order_id': '01a0d03f-ac88-7cb1-863a-244035c44655', 'cancel_http': 200, 'ok': True}]`
- **leftover_resting=no**

## trade_size_observed rule (verified)
- Endpoint: `GET /trade-api/v2/markets/trades?ticker=&min_ts=&max_ts=`
- Count when `yes_price_dollars == limit_price` AND `taker_book_side == "ask"` (hits resting YES bids)
- Sum `count_fp`; zeros recorded as `"0.00"` (never null on success)

## Calibration metrics (NOT RUN — samples only)
- abs_err_contracts: null
- signed_bias: null
- brier: null
- pnl: null

## Failure mode counts
`{"ok|cancel_fail_503": 1, "place_rejected_503:{\"error\": {\"code\": \"service_unavailable\", \"message\": \"service_unavailable\"}}": 1}`

## Blockers
- None

## Evidence
- [V] demo key-id + Ed25519 PEM loaded
- [H] balance 200 funded={0: 100.0, 1: 0.0, 2: 0.0, 3: 0.0}
- [V] pre-run resting=[]
- [V] discovered 78 markets
- [V] final resting=[] leftover=no
- [V] n_attempted=14 n_success=12

## Sibling JSON
`/workspace/lab/governance/astra/packets/r3_p2_queue_position/results/demo_trade_step_sample_series_retry.json`

## Does NOT authorize
Live orders, invent trade_size/fill/metrics, knob retune, Q6-000, Examiner promote of cancel-model from static KEEP.
